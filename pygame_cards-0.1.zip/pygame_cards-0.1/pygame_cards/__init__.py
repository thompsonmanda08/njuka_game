""" pygame_cards is a package for creating simple card games powered by pygame framework.
Contains following modules:
....
"""
